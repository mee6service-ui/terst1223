# Discord OAuth & Bot Setup (quick steps)

1. Create a Discord Application: https://discord.com/developers/applications
   - Create a new application and copy `Client ID` and `Client Secret`.
   - Under "OAuth2 -> Redirects" add: `http://localhost:3000/auth/discord/callback`

2. Create a Bot
   - In the same application, go to "Bot" and create a bot; copy the Bot Token.
   - Invite the bot to your server with the proper permissions (Manage Roles / Create Invite / etc.).

3. Add required OAuth2 scopes for the OAuth2 URL
   - Scopes: `identify email guilds.join`

4. Configure server `server/config.js` (edit values directly)
   - `DISCORD_CLIENT_ID`, `DISCORD_CLIENT_SECRET`, `DISCORD_BOT_TOKEN`, `DISCORD_GUILD_ID`, `DISCORD_REDIRECT_URI`, `SESSION_SECRET`, `FRONTEND_ORIGIN`

5. Run the server

```bash
cd server
npm install
npm run start
```

6. Run frontend

```bash
# from repo root
npm install
npm run dev
```

Notes:
- `guilds.join` requires the bot to be present in the guild and for the application to request the scope. The server uses the bot token to add the user to the guild using the user's access token.
- For production, use HTTPS, set `cookie.secure=true`, and store sessions in a DB.
