// Edit these values directly (do NOT commit sensitive real tokens).
// This replaces using a .env file per your request.
module.exports = {
  DISCORD_CLIENT_ID: '1163161027299508385',
  DISCORD_CLIENT_SECRET: 'YLQ7BI6p5s0D29Tf7U-UY6iR7MCyI_44',
  DISCORD_BOT_TOKEN: 'MTE2MzE2MTAyNzI5OTUwODM4NQ.G3avc0.SXWnDH5DijIB6ECY8Gdn97phgoXl42attCjIKg',
  DISCORD_GUILD_ID: '1159264583555489874',
  DISCORD_REDIRECT_URI: 'http://127.0.0.1:3000/auth/discord/callback',
  SESSION_SECRET: 'a8f3c1e9d4b2c8f1e6a9d3c7b4e2f8a1c9d6e4b3f7a2c5e8d9b1f4c6a7',
  FRONTEND_ORIGIN: '',
  // Optional: role to assign after join
  DISCORD_ASSIGN_ROLE_ID: '1159917428420133019'
};
