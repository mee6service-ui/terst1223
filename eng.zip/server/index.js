const express = require('express');
const axios = require('axios');
const session = require('express-session');
const cors = require('cors');
const qs = require('querystring');
const config = require('./config');
const fs = require('fs').promises;
const path = require('path');

// Utility: prune expired users from users.json
const USERS_FILE = path.join(__dirname, 'users.json');
async function pruneExpiredUsersFile() {
  try {
    const raw = await fs.readFile(USERS_FILE, 'utf8');
    const users = JSON.parse(raw || '{}');
    const now = new Date();
    let changed = false;
    for (const id of Object.keys(users)) {
      const item = users[id];
      if (!item || !item.expiry_time) continue;
      const exp = new Date(item.expiry_time);
      if (isNaN(exp) || exp <= now) {
        delete users[id];
        changed = true;
      }
    }
    if (changed) {
      await fs.writeFile(USERS_FILE, JSON.stringify(users, null, 2), 'utf8');
    }
  } catch (e) {
    // If file doesn't exist or is invalid, ignore — nothing to prune
  }
}

// Run a prune at startup and schedule periodic pruning every 15 minutes
pruneExpiredUsersFile().catch(() => {});
setInterval(() => pruneExpiredUsersFile().catch(() => {}), 15 * 60 * 1000);

const app = express();

const PORT = process.env.PORT || 3000;
const FRONTEND_ORIGIN = config.FRONTEND_ORIGIN || 'http://localhost:5173';

app.use(express.json());
app.use(cors({ origin: FRONTEND_ORIGIN, credentials: true }));
app.use(
  session({
    secret: config.SESSION_SECRET || 'change_this_secret',
    resave: false,
    saveUninitialized: false,
    cookie: { secure: false } // set secure:true when using HTTPS
  })
);

const DISCORD_TOKEN_URL = 'https://discord.com/api/oauth2/token';
const DISCORD_API_BASE = 'https://discord.com/api';

app.get('/auth/discord', (req, res) => {
  const params = qs.stringify({
    client_id: config.DISCORD_CLIENT_ID,
    redirect_uri: config.DISCORD_REDIRECT_URI,
    response_type: 'code',
    scope: 'identify email guilds.join'
  });
  res.redirect(`https://discord.com/api/oauth2/authorize?${params}`);
});

app.get('/auth/discord/callback', async (req, res) => {
  const code = req.query.code;
  if (!code) return res.status(400).send('No code provided');

  try {
    // Exchange code for token
    const tokenRes = await axios.post(
      DISCORD_TOKEN_URL,
      qs.stringify({
        client_id: config.DISCORD_CLIENT_ID,
        client_secret: config.DISCORD_CLIENT_SECRET,
        grant_type: 'authorization_code',
        code,
        redirect_uri: config.DISCORD_REDIRECT_URI
      }),
      { headers: { 'Content-Type': 'application/x-www-form-urlencoded' } }
    );

    const { access_token, token_type } = tokenRes.data;

    // Fetch user
    const userRes = await axios.get(`${DISCORD_API_BASE}/users/@me`, {
      headers: { Authorization: `${token_type} ${access_token}` }
    });

    const user = userRes.data; // id, username, avatar, etc.

    // Try to add user to guild using bot token
    const guildId = config.DISCORD_GUILD_ID;
    const botToken = config.DISCORD_BOT_TOKEN;

    if (!guildId || !botToken) {
      console.warn('Guild ID or Bot Token not configured. Skipping guild join.');
    } else {
      try {
        // Add/Invite user to guild using guilds.join (requires user's access token + bot enabled in guild)
        await axios.put(
          `${DISCORD_API_BASE}/guilds/${guildId}/members/${user.id}`,
          { access_token },
          { headers: { Authorization: `Bot ${botToken}` } }
        );

        // Optional: assign a role if provided
        const roleId = config.DISCORD_ASSIGN_ROLE_ID;
        if (roleId) {
          await axios.patch(
            `${DISCORD_API_BASE}/guilds/${guildId}/members/${user.id}`,
            { roles: [roleId] },
            { headers: { Authorization: `Bot ${botToken}` } }
          );
        }
      } catch (err) {
        console.error('Failed to add user to guild:', err.response ? err.response.data : err.message);
      }
    }

    // Save minimal user info in session (do not store secrets)
    req.session.user = { id: user.id, username: `${user.username}#${user.discriminator}`, avatar: user.avatar };

    // Redirect to frontend Enter ID page
    res.redirect(`${FRONTEND_ORIGIN}/enter-id`);
  } catch (err) {
    console.error('OAuth callback error', err.response ? err.response.data : err.message);
    res.status(500).send('Authentication failed');
  }
});

// Get current session user
app.get('/api/me', (req, res) => {
  if (req.session && req.session.user) return res.json({ user: req.session.user });
  return res.status(401).json({ error: 'Not authenticated' });
});

// Dev-only helper: set a fake session user for testing (not enabled in production)
if (process.env.NODE_ENV !== 'production') {
  app.post('/__test_set_user', (req, res) => {
    const u = req.body || {};
    const user = {
      id: u.id || 'testuser',
      username: u.username || 'TestUser#0001',
      avatar: u.avatar || '902000207'
    };
    req.session.user = user;
    return res.json({ success: true, user });
  });
}

// Save provided game ID in session (placeholder for DB)
app.post('/api/save-id', (req, res) => {
  const { gameId } = req.body;
  if (!gameId) return res.status(400).json({ error: 'gameId required' });
  if (!req.session) return res.status(500).json({ error: 'Session not available' });
  req.session.gameId = gameId;
  res.json({ success: true });
});

// Save user data to server/users.json
app.post('/api/users', async (req, res) => {
  console.log('/api/users called', req.body && Object.keys(req.body));
  const { gameId } = req.body;
  if (!gameId) return res.status(400).json({ error: 'gameId required' });

  // determine duration: 3h if logged in via Discord, otherwise 2h
  const hours = req.session && req.session.user ? 3 : 2;
  const expiry = new Date(Date.now() + hours * 60 * 60 * 1000).toISOString();
  const timeNumber = `${hours}h`;

  // Minimal user object template — adjust fields as needed
  const userEntry = {
    type_getbackpack: 'default_backpack',
    avatar: (req.session && req.session.user && req.session.user.avatar) || '902000207',
    banner: '901000194',
    emotes: [],
    gun_id: '907292607',
    skin_equiped: 'd49ce2618195e66080c38566fa9fa561a3b6ce64',
    time_number: timeNumber,
    expiry_time: expiry
  };

  try {
    // Prune expired entries before saving
    await pruneExpiredUsersFile();

    let users = {};
    try {
      const raw = await fs.readFile(USERS_FILE, 'utf8');
      users = JSON.parse(raw || '{}');
    } catch (e) {
      users = {};
    }

    users[gameId] = userEntry;

    await fs.writeFile(USERS_FILE, JSON.stringify(users, null, 2), 'utf8');

    return res.json({ success: true, user: users[gameId] });
  } catch (err) {
    console.error('Failed to write users.json', err);
    return res.status(500).json({ error: 'Failed to save user' });
  }
});

// Return a single user entry if present
app.get('/api/users/:id', async (req, res) => {
  const id = req.params.id;
  if (!id) return res.status(400).json({ error: 'id required' });
  try {
    let users = {};
    try {
      const raw = await fs.readFile(USERS_FILE, 'utf8');
      users = JSON.parse(raw || '{}');
    } catch (e) {
      users = {};
    }

    const entry = users[id];
    if (!entry) return res.status(404).json({ error: 'not found' });
    return res.json({ user: entry });
  } catch (err) {
    console.error('Failed to read users.json', err);
    return res.status(500).json({ error: 'failed' });
  }
});

app.listen(PORT, () => console.log(`Auth server running on http://localhost:${PORT}`));
