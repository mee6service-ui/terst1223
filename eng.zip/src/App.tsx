import { MessageCircle } from 'lucide-react';
import { BACKEND_URL } from './config';

function App() {
  const handleDiscordAuth = () => {
    // Redirect to backend which initiates the OAuth2 flow
    window.location.href = `${BACKEND_URL}/auth/discord`;
  };

  const handleGuestUnlock = () => {
    // Simple fallback: navigate to enter-id (no auth)
    window.location.href = '/enter-id';
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-black flex items-center justify-center p-4 relative overflow-hidden">
      <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAwIiBoZWlnaHQ9IjIwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZGVmcz48cGF0dGVybiBpZD0iZ3JpZCIgd2lkdGg9IjQwIiBoZWlnaHQ9IjQwIiBwYXR0ZXJuVW5pdHM9InVzZXJTcGFjZU9uVXNlIj48cGF0aCBkPSJNIDQwIDAgTCAwIDAgMCA0MCIgZmlsbD0ibm9uZSIgc3Ryb2tlPSJyZ2JhKDI1NSwgMjU1LCAyNTUsIDAuMDMpIiBzdHJva2Utd2lkdGg9IjEiLz48L3BhdHRlcm4+PC9kZWZzPjxyZWN0IHdpZHRoPSIxMDAlIiBoZWlnaHQ9IjEwMCUiIGZpbGw9InVybCgjZ3JpZCkiLz48L3N2Zz4=')] opacity-30"></div>

      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-blue-500 rounded-full mix-blend-multiply filter blur-3xl opacity-10 animate-pulse"></div>
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-purple-500 rounded-full mix-blend-multiply filter blur-3xl opacity-10 animate-pulse delay-700"></div>

      <div className="relative w-full max-w-md">
        <div className="backdrop-blur-xl bg-white/5 border border-white/10 rounded-3xl shadow-2xl p-8 sm:p-10 transform transition-all duration-300 hover:shadow-blue-500/10 hover:shadow-3xl">
          <div className="text-center mb-8">
            <div className="inline-block p-3 bg-gradient-to-br from-blue-500 to-purple-600 rounded-2xl mb-4 shadow-lg">
              <div className="w-12 h-12 flex items-center justify-center">
                <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                </svg>
              </div>
            </div>
            <h1 className="text-3xl sm:text-4xl font-bold text-white mb-3 tracking-tight">
              Unlock Beta Server Account
            </h1>
            <p className="text-slate-400 text-sm sm:text-base">
              Sign in with Discord to join the server and unlock access
            </p>
          </div>

          <div className="space-y-4 mb-6">
            <button
              onClick={handleDiscordAuth}
              className="w-full group relative overflow-hidden rounded-xl bg-gradient-to-r from-indigo-600 via-blue-600 to-indigo-600 p-[2px] transition-all duration-300 hover:scale-[1.02] hover:shadow-xl hover:shadow-blue-500/50 active:scale-[0.98]"
            >
              <div className="absolute inset-0 bg-gradient-to-r from-indigo-600 via-blue-600 to-indigo-600 opacity-0 group-hover:opacity-100 transition-opacity duration-300 blur-xl"></div>
              <div className="relative flex items-center justify-center gap-3 bg-gradient-to-r from-indigo-600 to-blue-600 px-6 py-4 rounded-xl">
                <MessageCircle className="w-5 h-5 text-white" />
                <span className="flex-1 text-left font-semibold text-white text-base sm:text-lg">
                  Login with Discord
                </span>
              </div>
            </button>

            <button
              onClick={handleGuestUnlock}
              className="w-full group relative overflow-hidden rounded-xl bg-white/5 border-2 border-white/20 p-4 transition-all duration-300 hover:scale-[1.02] hover:bg-white/10 hover:border-white/30 hover:shadow-xl hover:shadow-white/10 active:scale-[0.98]"
            >
              <div className="flex items-center justify-center gap-3">
                <svg className="w-5 h-5 text-slate-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 11V7a4 4 0 118 0m-4 8v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2z" />
                </svg>
                <span className="flex-1 text-left font-semibold text-slate-200 text-base sm:text-lg">
                  Unlock without Discord
                </span>
              </div>
            </button>
          </div>

          <div className="text-center mb-6">
            <p className="text-slate-500 text-xs sm:text-sm">
              Need help? Contact us at{' '}
              <a
                href="mailto:feedback@example.com"
                className="text-blue-400 hover:text-blue-300 transition-colors duration-200 underline decoration-blue-400/30 hover:decoration-blue-300"
              >
                feedback@example.com
              </a>
            </p>
          </div>

          <div className="flex justify-center gap-4 pt-6 border-t border-white/10">
            <a
              href="https://www.instagram.com/k_elyamani6"
              target="_blank"
              rel="noopener noreferrer"
              className="p-3 rounded-xl bg-white/5 border border-white/10 text-slate-400 hover:text-white hover:bg-white/10 hover:border-white/20 hover:scale-110 transition-all duration-300"
              aria-label="Instagram"
            >
              <img src="/icons/instagram.svg" alt="Instagram" className="w-5 h-5" />
            </a>
            <a
              href="https://discord.gg/eAfdBEPBxg"
              target="_blank"
              rel="noopener noreferrer"
              className="p-3 rounded-xl bg-white/5 border border-white/10 text-slate-400 hover:text-white hover:bg-white/10 hover:border-white/20 hover:scale-110 transition-all duration-300"
              aria-label="Discord"
            >
              <img src="/icons/discord.svg" alt="Discord" className="w-5 h-5" />
            </a>
          </div>
        </div>

        <div className="mt-8 text-center">
          <p className="text-slate-500 text-xs">
            By continuing, you agree to our Terms of Service
          </p>
        </div>
      </div>
    </div>
  );
}

export default App;
