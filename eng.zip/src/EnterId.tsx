import { useEffect, useState } from 'react';
import { BACKEND_URL } from './config';

export default function EnterId() {
  const [user, setUser] = useState(null as any);
  const [gameId, setGameId] = useState('');
  const [status, setStatus] = useState('');

  useEffect(() => {
    // Try to fetch current user from backend session
    fetch(`${BACKEND_URL}/api/me`, { credentials: 'include' })
      .then((r) => {
        if (!r.ok) throw new Error('Not authenticated');
        return r.json();
      })
      .then((d) => setUser(d.user))
      .catch(() => setUser(null));
  }, []);

  const submit = async (e: any) => {
    e.preventDefault();
    if (!gameId.trim()) {
      setStatus('Please enter a valid ID');
      return;
    }
    const id = gameId.trim();
    localStorage.setItem('gameId', id);

    try {
      // Check existing user
      const check = await fetch(`${BACKEND_URL}/api/users/${encodeURIComponent(id)}`, {
        credentials: 'include'
      });
      if (check.ok) {
        const j = await check.json();
        const expiry = new Date(j.user.expiry_time);
        const now = new Date();
        if (expiry > now) {
          // active
          window.location.href = `/id-result?gameId=${encodeURIComponent(id)}&status=active`;
          return;
        } else {
          // expired
          window.location.href = `/id-result?gameId=${encodeURIComponent(id)}&status=expired`;
          return;
        }
      }

      // If not found, create a new entry and show added
      const usersRes = await fetch(`${BACKEND_URL}/api/users`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ gameId: id })
      });
      if (usersRes.ok) {
        window.location.href = `/id-result?gameId=${encodeURIComponent(id)}&status=added`;
        return;
      }

      setStatus('Saved locally. Backend save failed.');
    } catch (err) {
      setStatus('Saved locally. Backend unavailable.');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-black flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="backdrop-blur-xl bg-white/5 border border-white/10 rounded-3xl shadow-2xl p-8">
          <h2 className="text-2xl font-bold text-white mb-4">Enter Your ID</h2>
          {user ? (
            <div className="mb-4 text-slate-300">
              Logged in as <strong className="text-white">{user.username}</strong>
            </div>
          ) : (
            <div className="mb-4 text-slate-400">Not logged in (you can still continue)</div>
          )}

          <form onSubmit={submit} className="space-y-4">
            <input
              value={gameId}
              onChange={(e: any) => setGameId(e.target.value)}
              placeholder="Game ID / User ID"
              className="w-full p-3 rounded-xl bg-white/5 border border-white/10 text-white placeholder-slate-400"
            />

            <button className="w-full py-3 rounded-xl bg-gradient-to-r from-indigo-600 to-blue-600 text-white font-semibold">
              Submit
            </button>
          </form>

          {status && <div className="mt-4 text-sm text-green-400">{status}</div>}
        </div>
      </div>
    </div>
  );
}
