import { useEffect, useState } from 'react';
import { BACKEND_URL } from './config';

function readQuery() {
  const qp = new URLSearchParams(window.location.search);
  return { gameId: qp.get('gameId') || undefined, status: qp.get('status') || undefined };
}

export default function IdResult() {
  const { gameId, status } = readQuery();
  const [user, setUser] = useState<any>(null);
  const [msg, setMsg] = useState('');
  const [remaining, setRemaining] = useState<string | null>(null);

  useEffect(() => {
    if (!gameId) return;
    fetch(`${BACKEND_URL}/api/users/${encodeURIComponent(gameId)}`)
      .then((r) => r.json())
      .then((d) => setUser(d.user))
      .catch(() => setUser(null));
  }, [gameId]);

  // Start countdown when user is loaded
  useEffect(() => {
    let timer: any;
    function update() {
      if (!user || !user.expiry_time) {
        setRemaining(null);
        return;
      }
      const exp = new Date(user.expiry_time).getTime();
      const now = Date.now();
      const diff = exp - now;
      if (diff <= 0) {
        setRemaining('Expired');
        return;
      }
      const totalSeconds = Math.floor(diff / 1000);
      const hours = Math.floor(totalSeconds / 3600);
      const minutes = Math.floor((totalSeconds % 3600) / 60);
      const seconds = totalSeconds % 60;
      setRemaining(`${hours}h ${String(minutes).padStart(2, '0')}m ${String(seconds).padStart(2, '0')}s`);
    }

    update();
    timer = setInterval(update, 1000);
    return () => clearInterval(timer);
  }, [user]);

  const goMain = () => (window.location.href = '/');

  const readd = async () => {
    if (!gameId) return;
    try {
      const res = await fetch(`${BACKEND_URL}/api/users`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ gameId })
      });
      if (!res.ok) throw new Error('failed');
      const j = await res.json();
      setUser(j.user);
      setMsg('Re-added successfully');
    } catch (e) {
      setMsg('Failed to re-add ID');
    }
  };

  return (
    <div className="min-h-screen bg-slate-900 text-white flex items-center justify-center p-6">
      <div className="w-full max-w-md bg-white/5 border border-white/10 rounded-2xl p-6">
        <h2 className="text-xl font-bold mb-4">ID Status</h2>
        <div className="mb-4">
          <div className="text-sm text-slate-300">ID</div>
          <div className="font-mono text-lg">{gameId || '—'}</div>
        </div>
        <div className="mb-4">
          <div className="text-sm text-slate-300">Expiry</div>
          <div className="font-medium">{user ? user.expiry_time : 'Not available'}</div>
          {remaining && (
            <div className="mt-2 text-sm text-slate-300">Remaining: <span className="font-mono">{remaining}</span></div>
          )}
        </div>

        <div className="flex gap-3">
          {status === 'active' && (
            <button onClick={goMain} className="px-4 py-2 rounded bg-indigo-600">Reset</button>
          )}
          {status === 'expired' && (
            <button onClick={readd} className="px-4 py-2 rounded bg-green-600">Re-add ID</button>
          )}
          {status === 'added' && (
            <button onClick={goMain} className="px-4 py-2 rounded bg-indigo-600">Done</button>
          )}
        </div>

        {msg && <div className="mt-4 text-sm text-green-300">{msg}</div>}
      </div>
    </div>
  );
}
