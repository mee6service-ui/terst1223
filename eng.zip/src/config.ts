// Frontend backend URL configuration (edit if your backend runs elsewhere)
export const BACKEND_URL = 'http://localhost:3000';
