// Project-wide global declarations to help the editor when node_modules aren't installed.
declare module 'vite' {
  export function defineConfig(config: any): any;
  export type Plugin = any;
}

declare module '@vitejs/plugin-react' {
  import type { Plugin } from 'vite';
  export default function reactPlugin(options?: any): Plugin;
}
