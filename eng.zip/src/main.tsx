import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import EnterId from './EnterId';
import IdResult from './IdResult';
import './index.css';

const pathname = window.location.pathname;

createRoot(document.getElementById('root')!).render(
  <>
    {pathname === '/enter-id' ? (
        <EnterId />
      ) : pathname === '/id-result' ? (
        <IdResult />
      ) : (
        <App />
      )}
  </>
);
