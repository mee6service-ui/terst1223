// Lightweight shims to avoid TypeScript/IDE errors when node_modules are not installed.
// These are temporary and safe for editor-only usage. Install real deps and remove this file later.

declare module 'lucide-react' {
  import * as React from 'react';
  export const MessageCircle: React.FC<any>;
  export const Send: React.FC<any>;
  const _default: any;
  export default _default;
}

declare module 'react-dom/client' {
  export function createRoot(container: any): { render: (node: any) => void };
  const anyExport: any;
  export default anyExport;
}

declare module 'react/jsx-runtime' {
  export function jsx(type: any, props: any, key?: any): any;
  export function jsxs(type: any, props: any, key?: any): any;
  export function jsxDEV(type: any, props: any, key?: any): any;
}

declare namespace JSX {
  interface IntrinsicElements {
    [elemName: string]: any;
  }
}

// Minimal react module shim to silence editor/TS errors when node_modules are missing.
declare module 'react' {
  export type ReactNode = any;
  export type FormEvent = any;
  export type FC<P = {}> = (props: P & { children?: ReactNode }) => any;
  export const StrictMode: any;

  const React: {
    createElement: any;
    Component: any;
    Fragment: any;
    StrictMode: any;
  };
  export default React;
  export function useState<T = any>(initial?: T): [T, (v: any) => void];
  export function useEffect(fn: () => void | (() => void), deps?: any[]): void;
  export function useRef<T = any>(init?: T): { current: T };
  export function useContext(ctx: any): any;
  export function useCallback(fn: any, deps?: any[]): any;
  export function useMemo(fn: any, deps?: any[]): any;
  export function useLayoutEffect(fn: any, deps?: any[]): void;
}

// Shims for Vite and common plugins when node_modules aren't installed
declare module 'vite' {
  export function defineConfig(config: any): any;
  export type Plugin = any;
}

declare module '@vitejs/plugin-react' {
  import type { Plugin } from 'vite';
  export default function reactPlugin(options?: any): Plugin;
}
